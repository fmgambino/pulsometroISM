#pragma once
// No se adjunto el logo oficial. Esta version muestra una placa tipografica ISM.
// Reemplazar por bitmap monocromo oficial y activar HAS_OFFICIAL_LOGO.
constexpr bool HAS_OFFICIAL_LOGO=false;
const uint8_t OFFICIAL_LOGO[1024] PROGMEM={0}; // bitmap 128x64, drawBitmap
const char WEB_LOGO[] PROGMEM=R"SVG(<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="26" fill="#123c66"/><text x="60" y="72" text-anchor="middle" fill="white" font-family="sans-serif" font-size="38" font-weight="bold">ISM</text></svg>)SVG";
